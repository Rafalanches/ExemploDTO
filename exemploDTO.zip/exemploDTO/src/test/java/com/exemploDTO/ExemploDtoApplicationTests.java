package com.exemploDTO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploDtoApplicationTests {

	@Test
	void contextLoads() {
	}

}
