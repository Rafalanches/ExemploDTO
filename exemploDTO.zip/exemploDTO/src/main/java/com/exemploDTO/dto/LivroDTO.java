package com.exemploDTO.dto;

public record LivroDTO (Long id, String titulo, String autor){
	
}
